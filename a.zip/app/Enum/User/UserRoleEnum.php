<?php

namespace App\Enum\User;

class UserRoleEnum
{
    const SELLER = "SELLER";

    const CUSTOMER = "CUSTOMER";

    const ADMIN = "ADMIN";
}
