<?php

namespace App\Enum\Response;

class ResponseStatusEnum
{
    const CANCELED = 'CANCELED';

    const ACTIVE = 'ACTIVE';

    const CHECKED = 'CHECKED';
}
