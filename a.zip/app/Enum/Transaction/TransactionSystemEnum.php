<?php

namespace App\Enum\Transaction;

class TransactionSystemEnum
{
    const YOOKASSA = "YOOKASSA";
}
