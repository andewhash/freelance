<?php $__env->startSection('content'); ?>
    <header>
        <div class="page-header min-vh-75">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 mt-8 position-relative z-index-1">
                        <div class="d-flex align-items-center">
                            <svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18.5714 7.07812C18.5714 7.24182 18.4747 7.42039 18.2813 7.61384L14.2299 11.5647L15.1897 17.1451C15.1972 17.1972 15.2009 17.2716 15.2009 17.3683C15.2009 17.5246 15.16 17.6548 15.0781 17.7589C15.0037 17.8705 14.8921 17.9263 14.7433 17.9263C14.6019 17.9263 14.4531 17.8817 14.2969 17.7924L9.28571 15.1585L4.27455 17.7924C4.11086 17.8817 3.96205 17.9263 3.82813 17.9263C3.67188 17.9263 3.55283 17.8705 3.47098 17.7589C3.39658 17.6548 3.35938 17.5246 3.35938 17.3683C3.35938 17.3237 3.36682 17.2493 3.3817 17.1451L4.34152 11.5647L0.279018 7.61384C0.093006 7.41295 0 7.23437 0 7.07812C0 6.80283 0.208333 6.6317 0.625 6.56473L6.22768 5.75L8.73884 0.671874C8.88021 0.366815 9.0625 0.214285 9.28571 0.214285C9.50893 0.214285 9.69122 0.366815 9.83259 0.671874L12.3438 5.75L17.9464 6.56473C18.3631 6.6317 18.5714 6.80283 18.5714 7.07812Z" fill="#EC407A" />
                            </svg>
                            <p class="text-primary font-weight-bold mb-0 ms-2">
                                300+ Проверенных Заказчиков
                            </p>
                        </div>
                        <h1>Freelance</h1>
                        <p class="text-lg mt-3">
                            Откройте новую жизнь в мире фриланса. Работайте с дома через безопасные сделаки на микрозадачах
                        </p>
                        <div class="d-flex align-items-center mb-4">
                            <div class="avatar-group">
                                <a href="javascript:;" class="avatar avatar-sm rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Martin Doe" data-bs-original-title="Martin Doe">
                                    <img alt="Image placeholder" src="https://demos.creative-tim.com/material-dashboard-pro/assets/img/bruce-mars.jpg">
                                </a>
                                <a href="javascript:;" class="avatar avatar-sm rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Romina Hadid" data-bs-original-title="Romina Hadid">
                                    <img alt="Image placeholder" src="https://demos.creative-tim.com/material-dashboard-pro/assets/img/team-5.jpg">
                                </a>
                                <a href="javascript:;" class="avatar avatar-sm rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Alexa Tompson" data-bs-original-title="Alexa Tompson">
                                    <img alt="Image placeholder" src="https://demos.creative-tim.com/material-dashboard-pro/assets/img/team-3.jpg">
                                </a>
                            </div>
                            <p class="mb-0 ms-2"> 1,300+  Продавцов</p>
                        </div>
                        <div class="d-block d-md-flex" style="gap: 10px;">

                            <a href="<?php echo e(route('login.page')); ?>" target="_blank" class="btn w-100 w-md-auto btn-primary">Продавец</a>
                            <a href="<?php echo e(route('login.page')); ?>" target="_blank" class="btn w-100 w-md-auto btn-outline-primary">Заказчик</a>

                        </div>
                    </div>
                    <svg class="position-absolute top-0" width="1231" height="1421" viewBox="0 0 1231 1421" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g opacity="0.12786" filter="url(#filter0_f_31_15)">
                            <ellipse cx="811.5" cy="602.5" rx="675.5" ry="682.5" fill="url(#paint0_linear_31_15)" />
                        </g>
                        <defs>
                            <filter id="filter0_f_31_15" x="0.085907" y="-215.914" width="1622.83" height="1636.83" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                                <feGaussianBlur stdDeviation="67.957" result="effect1_foregroundBlur_31_15" />
                            </filter>
                            <linearGradient id="paint0_linear_31_15" x1="804.405" y1="-136.203" x2="160.281" y2="643.776" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#7B4CFF" />
                                <stop offset="0.469471" stop-color="#EC407A" />
                                <stop offset="1" stop-color="white" />
                            </linearGradient>
                        </defs>
                    </svg>
                    <img class="position-absolute top-0 mt-n7 me-n12 end-0 w-70 z-index-3" src="/assets/img/perspective.png" alt="header-image">
                </div>
            </div>
        </div>
    </header>

<div class="card card-body mx-3 mx-md-4 mt-n6 z-index-1 position-relative">
    <section class="pt-3 pb-4" id="stats">
        <div class="container">
            <div class="row">
                <div class="col-lg-11 z-index-2 border-radius-xl mx-auto py-3">
                    <div class="row">
                        <div class="col-md-6 col-lg-3 position-relative">
                            <div class="p-3 text-center">
                                <h1 class="text-gradient text-primary"><span id="stats1" countTo="1000">0</span>+</h1>
                                <h5 class="mt-3">Положительных отзывов</h5>
                            </div>
                            <hr class="vertical dark">
                        </div>
                        <div class="col-md-6 col-lg-3 position-relative">
                            <div class="p-3 text-center">
                                <h1 class="text-gradient text-primary"> <span id="stats2" countTo="500"></span>+</h1>
                                <h5 class="mt-3">Заказов каждый день</h5>
                            </div>
                            <hr class="vertical dark">
                        </div>
                        <div class="col-md-6 col-lg-3 position-relative">
                            <div class="p-3 text-center">
                                <h1 class="text-gradient text-primary"> <span id="stats3" countTo="400"></span>+</h1>
                                <h5 class="mt-3">Заказчиков</h5>
                            </div>
                            <hr class="vertical dark">
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 text-center">
                                <h1 class="text-gradient text-primary">4.9/5</h1>
                                <h5 class="mt-3">Рейтинг платформы</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="my-5 py-5" id="components">
        <div class="container mt-sm-5 mt-3">
            <div class="row">
                <div class="col-lg-5">
                    <div class="position-sticky pb-lg-5 pb-3 mt-lg-0 mt-5 ps-2" style="top: 100px">
                        <h5 class="text-primary fw-bold text-uppercase text-lg">Что можно делать на бирже</h5>
                        <h3>Доступные задания</h3>
                        <h6 class="text-secondary font-weight-normal pe-3">
                            На фриланс бирже микрозадач можно выполнять различные задания, включая создание сайтов, тестирование, написание текстов и многое другое.
                        </h6>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="row">
                        <!-- 1. Создание сайтов -->
                        <div class="col-md-4 mt-md-0 mt-4">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-file-earmark-code" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Создание сайтов</h6>
                                </div>
                            </a>
                        </div>
                        <!-- 2. Написание текстов -->
                        <div class="col-md-4 mt-md-0 mt-4">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-pencil" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Написание текстов</h6>
                                </div>
                            </a>
                        </div>
                        <!-- 3. Тестирование -->
                        <div class="col-md-4 mt-md-0 mt-4">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-bug" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Тестирование</h6>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <!-- 4. Программирование -->
                        <div class="col-md-4 mt-md-0 mt-3">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-file-earmark-code" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Программирование</h6>
                                </div>
                            </a>
                        </div>
                        <!-- 5. Дизайн -->
                        <div class="col-md-4 mt-md-0 mt-4">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-paint-bucket" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Дизайн</h6>
                                </div>
                            </a>
                        </div>
                        <!-- 6. Разработка приложений -->
                        <div class="col-md-4 mt-md-0 mt-4">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-phone" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Разработка приложений</h6>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <!-- 7. Переводы -->
                        <div class="col-md-4 mt-md-0 mt-3">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-translate" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Переводы</h6>
                                </div>
                            </a>
                        </div>
                        <!-- 8. Видео монтаж -->
                        <div class="col-md-4 mt-md-0 mt-4">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-film" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">Видео монтаж</h6>
                                </div>
                            </a>
                        </div>
                        <!-- 9. SEO оптимизация -->
                        <div class="col-md-4 mt-md-0 mt-4">
                            <a href="#">
                                <div class="card shadow-lg move-on-hover min-height-140 max-height-140">
                                    <i class="bi bi-graph-up" style="font-size: 3rem; color: #007bff;"></i>
                                </div>
                                <div class="mt-2 ms-2">
                                    <h6 class="mb-0">SEO оптимизация</h6>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




    






































































































    <section id="faq">
        <div class="container mt-8" id="faq-section">
            <div class="row mb-5">
                <div class="col-lg-10 mx-auto text-center">
                    <h5 class="text-primary fw-bold text-uppercase text-lg">Часто задаваемые вопросы</h5>
                    <h2>Все, что вам нужно знать о фриланс-бирже </h2>
                    <p class="text-secondary lead font-weight-normal pe-3">
                        Наша платформа предоставляет возможность выполнять небольшие задания для различных проектов.
                        С помощью неё вы можете зарабатывать, выполняя задачи в удобное для вас время и на различных уровнях сложности.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 mx-auto">
                    <div class="accordion" id="accordionFaq">
                        <div class="accordion-item mb-3">
                            <h5 class="accordion-header" id="headingOne">
                                <button class="accordion-button border-bottom font-weight-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Что такое фриланс-биржа микрозадач?
                                    <i class="collapse-close fa fa-plus text-xs pt-1 position-absolute end-0"></i>
                                    <i class="collapse-open fa fa-minus text-xs pt-1 position-absolute end-0"></i>
                                </button>
                            </h5>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionFaq">
                                <div class="accordion-body text-sm opacity-8">
                                    Это онлайн-платформа, где пользователи могут найти микрозадачи для выполнения. Задания могут быть разного типа: от простых операций, таких как сбор информации или транскрибирование текста, до более сложных задач, требующих специфических навыков.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item mb-3">
                            <h5 class="accordion-header" id="headingTwo">
                                <button class="accordion-button border-bottom font-weight-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Как начать работать на фриланс-бирже?
                                    <i class="collapse-close fa fa-plus text-xs pt-1 position-absolute end-0"></i>
                                    <i class="collapse-open fa fa-minus text-xs pt-1 position-absolute end-0"></i>
                                </button>
                            </h5>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionFaq">
                                <div class="accordion-body text-sm opacity-8">
                                    Для начала работы на бирже необходимо зарегистрироваться, создать профиль и указать свои навыки. После этого вы сможете приступать к выполнению заданий, которые вам подходят.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item mb-3">
                            <h5 class="accordion-header" id="headingThree">
                                <button class="accordion-button border-bottom font-weight-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Как оплачиваются задания?
                                    <i class="collapse-close fa fa-plus text-xs pt-1 position-absolute end-0"></i>
                                    <i class="collapse-open fa fa-minus text-xs pt-1 position-absolute end-0"></i>
                                </button>
                            </h5>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionFaq">
                                <div class="accordion-body text-sm opacity-8">
                                    Оплата происходит через платформу с использованием различных методов: банковские карты, электронные кошельки или криптовалюты. Выплата осуществляется после завершения задания и его проверки заказчиком.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item mb-3">
                            <h5 class="accordion-header" id="headingFour">
                                <button class="accordion-button border-bottom font-weight-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    Какие типы заданий есть на бирже?
                                    <i class="collapse-close fa fa-plus text-xs pt-1 position-absolute end-0"></i>
                                    <i class="collapse-open fa fa-minus text-xs pt-1 position-absolute end-0"></i>
                                </button>
                            </h5>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionFaq">
                                <div class="accordion-body text-sm opacity-8">
                                    Задания могут варьироваться от простых — например, тестирование сайтов или выполнение простых действий в социальных сетях, до более сложных, таких как написание текстов, разработка программного обеспечения или создание дизайнов.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item mb-3">
                            <h5 class="accordion-header" id="headingFive">
                                <button class="accordion-button border-bottom font-weight-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    Как узнать, что заказчик доволен моей работой?
                                    <i class="collapse-close fa fa-plus text-xs pt-1 position-absolute end-0"></i>
                                    <i class="collapse-open fa fa-minus text-xs pt-1 position-absolute end-0"></i>
                                </button>
                            </h5>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionFaq">
                                <div class="accordion-body text-sm opacity-8">
                                    После выполнения задания заказчик может оценить вашу работу и оставить отзыв. Если отзыв положительный, это поможет вам получить больше заданий в будущем. Важно всегда поддерживать высокий уровень качества выполнения задач.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/Work/projects/freelance/resources/views/index.blade.php ENDPATH**/ ?>