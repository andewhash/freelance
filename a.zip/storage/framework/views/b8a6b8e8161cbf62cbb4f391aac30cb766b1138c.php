<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-2 px-md-4">
        <div class="page-header min-height-300 border-radius-xl mt-4" style="background-image: url('https://images.unsplash.com/photo-1531512073830-ba890ca4eba2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80');">
            <span class="mask bg-gradient-dark opacity-6"></span>
        </div>
        <div class="row mt-4">
            <!-- Левая панель с чатами -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Чаты</h5>
                    </div>
                    <div class="card-body">
                        <?php if($chats->isEmpty()): ?>
                            <p>Пока тут пусто. Когда появятся чаты, они отобразятся здесь.</p>
                        <?php else: ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <a href="<?php echo e(route('profile.chats.show', $chat->id)); ?>">
                                            <?php echo e($chat->seller_id == auth()->id() ? $chat->customer->name : $chat->seller->name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Правая панель -->
            <div class="col-md-8">
                <div class="card" style="min-height: 500px">
                    <div class="card-header">
                        <h5>Выберите чат</h5>
                    </div>
                    <div class="card-body">
                        <p>Выберите чат слева для начала общения.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/Work/projects/freelance/resources/views/chats/index.blade.php ENDPATH**/ ?>